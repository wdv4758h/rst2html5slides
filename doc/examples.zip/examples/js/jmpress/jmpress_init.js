$(function() {
    $('#jmpress').jmpress();
});