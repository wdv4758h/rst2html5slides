$(function() {
    $.deck("slide");
});
